from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators import LoadDimensionOperator
from helpers import SqlQueries


def load_dimensional_tables_dag(
        parent_dag_name,
        task_id,
        redshift_conn_id,
        aws_credentials_id,
        delete_load,
        table_name,
        sql_query,
        *args, **kwargs):
        
        dag = DAG(f"{parent_dag_name}.{task_id}", **kwargs)
        """
        Returns a DAG and inserts data
        """

        load_dimension_table = LoadDimensionOperator(
            task_id=f"load_{table_name}_dim_table",
            dag=dag,
            table=table_name,
            delete_load=delete_load,
            redshift_conn_id=redshift_conn_id,
            aws_credentials_id=aws_credentials_id,
            sql_query=sql_query
        )

        load_dimension_table

        return dag