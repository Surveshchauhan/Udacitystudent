from helpers.sql_queries import SqlQueries
from helpers.sql_queries1 import SqlQueries1
__all__ = [
    'SqlQueries',
    'SqlQueries1',
]